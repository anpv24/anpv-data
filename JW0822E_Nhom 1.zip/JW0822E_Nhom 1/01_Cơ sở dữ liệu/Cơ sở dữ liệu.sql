create database eshopDB;
use eshopDB;
create table category (
	categoryId int primary key,
    categoryName varchar(50) not null,
    status int 
);
create table product (
	productId int primary key,
    productName varchar(50) not null,
    price int,
    originalPrice int,
    viewCount int,
    description varchar(512),
    status int,
    categoryId int,
    foreign key (categoryId) references category (categoryId)
);
create table productImage(
	imageId int primary key,
    imagePath varchar(500),
    isDefault int,
    productId int,
    foreign key (productId) references product(productId)
);
create table productColor(
	colorId int primary key,
    colorName varchar(100),
	productId int,
	foreign key (productId) references product(productId)
);
create table productSize(
	sizeId int primary key,
    sizeName varchar(100),
	productId int,
	foreign key (productId) references product(productId)
);
create table users(
	userId int primary key,
    username varchar(50),
    password varchar(50),
    fullname varchar(100),
    avatar varchar(512),
    email varchar(50),
    phone varchar(20),
    address varchar(300),
    isAdmin int
);
create table orders(
	orderId int primary key,
    userId int,
    foreign key (userId) references users(userId),
    totalMoney int,
    payment varchar(50),
    bookingDate datetime,
    deliveryDate datetime,
    shippingWay varchar(100),
    state int,
    color varchar(50),
    size varchar(50),
    note varchar(500),
    transportFee int
);
create table orderDetail(
	orderDetailId int primary key,
    productId int,
    foreign key (productId) references product(productId),
    orderId int,
    foreign key (orderId) references orders(orderId),
    quantity int
);

create table product_detail(
	monitor varchar(100),
    os varchar(50),
    rearCamera varchar(100),
    frontCamera varchar(100),
    chip varchar(100),
    ram varchar(50),
    rom varchar(50),
    sim varchar(100),
    battery varchar(50),
    charge varchar(50),
	productId int,
    primary key (productId),
    foreign key (productId) references product(productId)
);
